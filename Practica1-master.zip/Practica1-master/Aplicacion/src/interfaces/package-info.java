/**
 * Contiene la clase que es responsable de implementar interfaz de texto del programa.
 **/

package interfaces;
