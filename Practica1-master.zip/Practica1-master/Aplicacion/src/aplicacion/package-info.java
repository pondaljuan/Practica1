/**
 * Paquete contiene la clase de arranque de la aplicacion.
 **/

package aplicacion;

