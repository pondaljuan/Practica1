/**
 * El paquete contiene la informacio de los coches y la forma de almacenar esos coches en una lista ademas de poder moficicar esa lista<i>Coches.java</i> y <i>Catalogo.java</i>.
 **/

package dominio;
